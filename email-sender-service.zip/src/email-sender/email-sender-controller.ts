import { Controller } from '@nestjs/common';
import { Ctx, EventPattern, Payload, RmqContext } from '@nestjs/microservices';
import { EmailSenderService } from './email-sender.service';

@Controller()
export class EmailSenderController {
  constructor(private readonly emailSenderService: EmailSenderService) {}

  @EventPattern('sales-report')
  async handleSalesReport(@Payload() data: any, @Ctx() context: RmqContext) {
    this.emailSenderService.handleSalesReport(data);

    // const channel = context.getChannelRef();
    //  const originalMessage = context.getMessage();
    //   try { await this.emailSenderService.handleSalesReport(data);
    //      channel.ack(originalMessage); // Manually acknowledge the message
    //       }
    //   catch (error) {
    //          console.error('Error processing message:', error); // Optionally, handle message requeueing or dead-letter queueing here 
    //          }
  }
}
