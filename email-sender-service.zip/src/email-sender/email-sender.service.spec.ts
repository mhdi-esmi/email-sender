import { Test, TestingModule } from '@nestjs/testing';
import { EmailSenderService } from './email-sender.service';
import { ConfigModule, ConfigService } from '@nestjs/config';

describe('EmailSenderService', () => {
  let service: EmailSenderService;
  let configService: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule.forRoot()],
      providers: [
        EmailSenderService,
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn().mockReturnValue('mock-value'),
          },
        },
      ],
    }).compile();

    service = module.get<EmailSenderService>(EmailSenderService);
    configService = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should process sales report', async () => {
    const report = { totalSales: 100 };

    // Mock console.log before invoking handleSalesReport
    const logSpy = jest.spyOn(console, 'log').mockImplementation();

    await service.handleSalesReport(report);

    expect(logSpy).toHaveBeenCalledWith('email sent!!!!!');
    expect(logSpy).toHaveBeenCalledWith(
      `Here is your daily sales report: ${JSON.stringify(report)}`,
    );

    logSpy.mockRestore(); // Restore original console.log
  });
});
