import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue } from 'bull';
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailSenderService {
  constructor(private readonly configService: ConfigService,) {}

  async handleSalesReport(report: any) {

    console.log("email sent!!!!!");
    console.log(`Here is your daily sales report: ${JSON.stringify(report)}`);
    // const transporter = nodemailer.createTransport({
    //   service: 'gmail',
    //   auth: {
    //     user: this.configService.get<string>('EMAIL_USER'),
    //     pass: this.configService.get<string>('EMAIL_PASS'),
    //   },
    // });

    // const mailOptions = {
    //   from: this.configService.get<string>('EMAIL_USER'),
    //   to: 'recipient@example.com',
    //   subject: 'Daily Sales Report',
    //   text: `Here is your daily sales report: ${JSON.stringify(report)}`,
    // };

    // try {
    //   await transporter.sendMail(mailOptions);
    //   console.log('Email sent successfully');
    // } catch (error) {
    //   console.error('Error sending email:', error);
    // }
  }
}

