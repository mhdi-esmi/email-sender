import { Test, TestingModule } from '@nestjs/testing';
import { EmailSenderController } from './email-sender-controller';
import { EmailSenderService } from './email-sender.service';
import { RmqContext } from '@nestjs/microservices';

describe('EmailSenderController', () => {
  let controller: EmailSenderController;
  let service: EmailSenderService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EmailSenderController],
      providers: [
        {
          provide: EmailSenderService,
          useValue: {
            handleSalesReport: jest.fn(),
          },
        },
      ],
    }).compile();

    controller = module.get<EmailSenderController>(EmailSenderController);
    service = module.get<EmailSenderService>(EmailSenderService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should handle sales report and call service', async () => {
    const data = { totalSales: 100 };
    const context = {
      getChannelRef: jest.fn(),
      getMessage: jest.fn(),
    } as unknown as RmqContext;

    await controller.handleSalesReport(data, context);

    expect(service.handleSalesReport).toHaveBeenCalledWith(data);
  });
});
