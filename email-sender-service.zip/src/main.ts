import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { EmailSenderModule } from './email-sender/email-sender.module';

async function bootstrap() {
const app = await NestFactory.createMicroservice<MicroserviceOptions>(
  EmailSenderModule,
  {
    transport: Transport.RMQ,
    options: {
      urls: ['amqp://127.0.0.1:5672'],
      queue: 'daily_sales_report',
      // noAck: false,
      // queueOptions: {
      //   durable: true,
      // },
    },
  },
);
await app.listen();
}
bootstrap();
