import { Controller, Get, Post, Body, Param, Query } from '@nestjs/common';
import { InvoiceService } from './invoice.service';
import { Invoice } from './schemas/invoice.schema';

@Controller('invoices')
export class InvoiceController {
  constructor(private readonly invoiceService: InvoiceService) {}

  @Post()
  async createInvoice(@Body() invoiceDto: Partial<Invoice>) {
    return this.invoiceService.createInvoice(invoiceDto);
  }

  @Get(':id')
  async getInvoiceById(@Param('id') id: string) {
    return this.invoiceService.getInvoiceById(id);
  }

  @Get()
  async getInvoices(@Query() query: { startDate?: string; endDate?: string }) {
    return this.invoiceService.getInvoices(query);
  }
}
