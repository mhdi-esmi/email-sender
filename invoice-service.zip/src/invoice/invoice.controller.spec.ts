import { Test, TestingModule } from '@nestjs/testing';
import { InvoiceController } from '../../invoice.controller';
import { InvoiceService } from '../../invoice.service';

describe('InvoiceController', () => {
  let controller: InvoiceController;
  let service: InvoiceService;

  const mockInvoiceService = {
    createInvoice: jest.fn().mockImplementation((dto) => ({
      ...dto,
      id: 'mockId',
      date: new Date(),
    })),
    getInvoiceById: jest.fn().mockImplementation((id) => ({
      id,
      customer: 'mockCustomer',
      amount: 100,
      reference: 'mockRef',
      date: new Date(),
      items: [],
    })),
    getInvoices: jest.fn().mockImplementation(() => []),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [InvoiceController],
      providers: [
        {
          provide: InvoiceService,
          useValue: mockInvoiceService,
        },
      ],
    }).compile();

    controller = module.get<InvoiceController>(InvoiceController);
    service = module.get<InvoiceService>(InvoiceService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should create an invoice', async () => {
    const dto = { customer: 'MHDI ESMI', amount: 100, reference: '123', items: [] };
    expect(await controller.createInvoice(dto)).toEqual({
      ...dto,
      id: 'mockId',
      date: expect.any(Date),
    });
    expect(service.createInvoice).toHaveBeenCalledWith(dto);
  });

  it('should retrieve an invoice by ID', async () => {
    expect(await controller.getInvoiceById('mockId')).toEqual({
      id: 'mockId',
      customer: 'mockCustomer',
      amount: 100,
      reference: 'mockRef',
      date: expect.any(Date),
      items: [],
    });
    expect(service.getInvoiceById).toHaveBeenCalledWith('mockId');
  });

  it('should retrieve all invoices', async () => {
    expect(await controller.getInvoices({})).toEqual([]);
    expect(service.getInvoices).toHaveBeenCalled();
  });
});