import { getModelToken } from '@nestjs/mongoose';
import { Test, TestingModule } from '@nestjs/testing';

import { NotFoundException } from '@nestjs/common';
import { InvoiceService } from '../../invoice.service';
import { Invoice } from '../../schemas/invoice.schema';

describe('InvoiceService', () => {
  let service: InvoiceService;
  // let model: Model<Invoice>;

  const mockInvoice = {
    _id: '1234567890',
    customer: 'Mhdi esmi',
    amount: 200,
    reference: 'INV123',
    date: new Date('2024-12-01T12:00:00Z'),
    items: [
      { sku: 'SKU001', qt: 2 },
      { sku: 'SKU002', qt: 1 },
    ],
  };

  const mockInvoiceModel = {
    create: jest.fn().mockResolvedValue(mockInvoice),
    findById: jest.fn().mockImplementation(() => ({
      exec: jest.fn().mockResolvedValue(mockInvoice), 
    })),
    find: jest
      .fn()
      .mockImplementation(() => ({
        exec: jest.fn().mockResolvedValue([mockInvoice]),
      })),
    exec: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InvoiceService,
        {
          provide: getModelToken(Invoice.name),
          useValue: mockInvoiceModel,
        },
      ],
    }).compile();

    service = module.get<InvoiceService>(InvoiceService);
    // model = module.get<Model<Invoice>>(getModelToken(Invoice.name));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('createInvoice', () => {
    const dto = {
      customer: 'Mhdi esmi',
      amount: 100,
      reference: 'INV123',
      items: [
        { sku: 'SKU001', qt: 2 },
        { sku: 'SKU002', qt: 1 },
      ],
    };
    it('should create and return an invoice', async () => {

      jest.spyOn(mockInvoiceModel, 'create').mockResolvedValueOnce(mockInvoice);

      const result = await service.createInvoice(dto);
      expect(result).toEqual(mockInvoice);
      expect(mockInvoiceModel.create).toHaveBeenCalledWith({
        ...dto,
        date: expect.any(Date),
      });

    });
    it('should throw an error if create fails', async () => {
      // Arrange: Mock create to throw an error
      mockInvoiceModel.create.mockRejectedValueOnce(
        new Error('Database error'),
      );

      // Act & Assert: Expect the method to throw an error
      await expect(service.createInvoice(dto)).rejects.toThrow(
        'Database error',
      );
    });
  });

  describe('getInvoiceById', () => {
    it('should return an invoice by ID', async () => {
      const id = '1234567890';

      const result = await service.getInvoiceById(id);
      expect(result).toEqual(mockInvoice);
      expect(mockInvoiceModel.findById).toHaveBeenCalledWith(id);
    });

    it('should throw NotFoundException if invoice is not found', async () => {
      const id = 'nonexistent';

      mockInvoiceModel.findById.mockImplementationOnce(() => ({
        exec: jest.fn().mockResolvedValue(null),
      }));

    await expect(service.getInvoiceById(id)).rejects.toThrow(NotFoundException);
    });
  });

  describe('getInvoices', () => {
    it('should return all invoices', async () => {
      const result = await service.getInvoices({});
      expect(result).toEqual([mockInvoice]);
      expect(mockInvoiceModel.find).toHaveBeenCalledWith({});
    });

    it('should return invoices within a date range', async () => {
      const filter = {
        startDate: '2024-12-01T00:00:00Z',
        endDate: '2024-12-02T23:59:59Z',
      };

      const query = {
        date: {
          $gte: new Date(filter.startDate),
          $lte: new Date(filter.endDate),
        },
      };

      const result = await service.getInvoices(filter);
      expect(result).toEqual([mockInvoice]);
      expect(mockInvoiceModel.find).toHaveBeenCalledWith(query);
    });
  });
});
