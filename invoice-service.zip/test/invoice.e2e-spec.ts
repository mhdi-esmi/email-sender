import { INestApplication } from '@nestjs/common';
import { getModelToken } from '@nestjs/mongoose';
import { Test, TestingModule } from '@nestjs/testing';
import { InvoiceModule } from '../src/invoice/invoice.module';
import * as request from 'supertest';


const mockInvoice = {
  customer: 'Mhdi esmi',
  amount: 100,
  reference: 'INV12345',
  // date: new Date(),
  items: [
    { sku: 'SKU001', qt: 2 },
    { sku: 'SKU002', qt: 1 },
  ],
};

const mockInvoiceModel = {
  create: jest.fn().mockResolvedValue(mockInvoice),
  findById: jest.fn().mockImplementation(() => ({
    exec: jest.fn().mockResolvedValue(mockInvoice),
  })),
  find: jest.fn().mockImplementation(() => ({
    exec: jest.fn().mockResolvedValue([mockInvoice]),
  })),
  exec: jest.fn(),
};

describe('InvoiceController (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [InvoiceModule],
    })
      .overrideProvider(getModelToken('Invoice'))
      .useValue(mockInvoiceModel)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('/POST /invoices (Create Invoice)', () => {
    return request(app.getHttpServer())
      .post('/invoices')
      .send(mockInvoice)
      .expect(201)
      .expect(mockInvoice);
  });

  it('/GET /invoices/:id (Invoice by ID)', () => {
    return request(app.getHttpServer())
      .get('/invoices/12345')
      .expect(200)
      .expect(mockInvoice);
  });

  it('/GET /invoices (All Invoices)', () => {
    return request(app.getHttpServer())
      .get('/invoices')
      .expect(200)
      .expect([mockInvoice]);
  });
});
